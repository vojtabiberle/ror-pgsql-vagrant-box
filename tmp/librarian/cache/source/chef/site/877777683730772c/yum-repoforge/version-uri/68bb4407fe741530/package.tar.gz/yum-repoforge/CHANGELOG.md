yum-repoforge Cookbook CHANGELOG
======================
This file is used to list changes made in each version of the yum-repoforge cookbook.

v0.4.0 (2014-09-02)
-------------------
- Add all attribute available to LWRP to allow for tuning

v0.3.0 (2014-06-11)
-------------------
#1 - Support for Amazon Linux 2014.03

v0.2.0 (2014-02-14)
-------------------
- Updating test harness

v0.1.4
------
Adding CHANGELOG.md

v0.1.0
------
initial release
