class Chef
  class Provider
    class MysqlService < Chef::Provider::LWRPBase
      def action_create
      end
    end
  end
end
